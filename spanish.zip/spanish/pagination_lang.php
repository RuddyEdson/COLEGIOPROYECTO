<?php
$lang['pagination_first_link'] = '&lsaquo; Primero';
$lang['pagination_next_link'] = '&gt;';
$lang['pagination_prev_link'] = '&lt;';
$lang['pagination_last_link'] = 'Último &rsaquo;';
